package compiler;

public class CompileTimeDescriptor {
}
